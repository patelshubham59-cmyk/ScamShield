package com.scamshield.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URI
import java.util.Locale

private val Green = Color(0xFF176B54)
private val Ink = Color(0xFF15332D)
private val Pale = Color(0xFFEAF4F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ScamShieldApp() }
    }
}

data class ScanResult(val level: String, val reasons: List<String>, val advice: String)

@Composable
fun ScamShieldApp() {
    var message by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var messageResult by remember { mutableStateOf<ScanResult?>(null) }
    var urlResult by remember { mutableStateOf<String?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color(0xFFF5F8F6))) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF5F8F6)) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(22.dp)).padding(20.dp)
                ) {
                    Text("🛡️  ScamShield", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("YOUR DIGITAL SAFETY COMPANION", color = Color(0xFFB8D8CC), fontSize = 10.sp)
                    Spacer(Modifier.height(24.dp))
                    Text("Stay one step ahead.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Check before you trust.", color = Color(0xFFD5E8E0), fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("BETA 1.0  •  US & UK", color = Color.White, fontSize = 11.sp)
                }

                CardSection(title = "Message safety checker", subtitle = "Paste a suspicious SMS, email or job offer.") {
                    OutlinedTextField(
                        value = message, onValueChange = { message = it; messageResult = null },
                        modifier = Modifier.fillMaxWidth(), minLines = 4,
                        placeholder = { Text("Paste the message here…") }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            message = "URGENT: Your bank account will be suspended. Click this link and enter your password immediately."
                        }) { Text("Bank example") }
                        OutlinedButton(onClick = {
                            message = "You won a $5,000 prize. Pay a processing fee now to claim it."
                        }) { Text("Prize example") }
                    }
                    Button(
                        onClick = { messageResult = analyzeMessage(message) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🛡️  Analyze message") }
                    messageResult?.let { ResultCard(it) }
                }

                CardSection(title = "Suspicious link checker", subtitle = "Inspect basic URL warning signs. Do not open suspicious links.") {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it; urlResult = null },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("https://example.com") }
                    )
                    Button(onClick = { urlResult = inspectUrl(url) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Check URL")
                    }
                    urlResult?.let {
                        Text(it, modifier = Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(12.dp)).padding(12.dp), color = Ink)
                    }
                }

                CardSection(title = "Safety checklist", subtitle = "Simple habits that reduce risk.") {
                    listOf(
                        "Never share one-time passwords or PINs.",
                        "Never pay a fee to receive a prize.",
                        "Verify senders using an official contact channel.",
                        "Do not trust urgency as proof of authenticity."
                    ).forEach { Text("✓  $it", color = Ink, fontSize = 14.sp) }
                }

                Text(
                    "Prototype only • Results are not verified security verdicts. A clean result does not prove a message or website is safe.",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun CardSection(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp), content = {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            content()
        })
    }
}

@Composable
private fun ResultCard(result: ScanResult) {
    val tint = when (result.level) {
        "HIGH" -> Color(0xFFB3261E)
        "CAUTION" -> Color(0xFF946200)
        else -> Green
    }
    Column(Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text("${result.level} RISK INDICATORS", color = tint, fontWeight = FontWeight.Bold)
        if (result.reasons.isEmpty()) Text("No common warning patterns detected.")
        result.reasons.forEach { Text("• $it", fontSize = 13.sp) }
        Spacer(Modifier.height(4.dp))
        Text(result.advice, fontSize = 13.sp, color = Ink)
    }
}

private fun analyzeMessage(input: String): ScanResult {
    if (input.isBlank()) return ScanResult("CAUTION", listOf("No message entered"), "Paste a message to analyze.")
    val rules = listOf(
        Regex("urgent|immediately|act now|within 24 hours|suspended|blocked", RegexOption.IGNORE_CASE) to "Urgency or threats",
        Regex("password|one.?time password|\\botp\\b|pin number|bank details|social security number", RegexOption.IGNORE_CASE) to "Request for sensitive information",
        Regex("won|winner|prize|lottery|claim your reward|free gift", RegexOption.IGNORE_CASE) to "Unexpected prize or reward",
        Regex("processing fee|pay a fee|send money|gift card|wire transfer|crypto", RegexOption.IGNORE_CASE) to "Unusual payment request",
        Regex("click here|verify your account|confirm your account|login now", RegexOption.IGNORE_CASE) to "Suspicious verification request",
        Regex("job offer|work from home|guaranteed income|easy money", RegexOption.IGNORE_CASE) to "Potentially suspicious job or income offer"
    )
    val hits = rules.filter { it.first.containsMatchIn(input) }.map { it.second }
    val level = when {
        hits.size >= 3 -> "HIGH"
        hits.isNotEmpty() -> "CAUTION"
        else -> "NO OBVIOUS FLAGS"
    }
    val advice = when (level) {
        "HIGH" -> "Do not click links, send money or share personal information. Verify through an independently obtained official contact."
        "CAUTION" -> "Pause and independently verify the sender and request before taking action."
        else -> "No common warning patterns were detected. This does not prove the message is genuine."
    }
    return ScanResult(level, hits, advice)
}

private fun inspectUrl(raw: String): String {
    if (raw.isBlank()) return "Enter a URL first."
    return try {
        val candidate = if (raw.contains("://")) raw else "https://$raw"
        val uri = URI(candidate)
        val host = uri.host ?: return "Invalid URL. Enter a valid web address."
        val flags = mutableListOf<String>()
        if (uri.scheme.lowercase(Locale.ROOT) != "https") flags.add("Not using HTTPS")
        if (uri.rawUserInfo != null) flags.add("Contains embedded login credentials")
        if (host.contains("xn--", ignoreCase = true)) flags.add("Internationalized domain; check for lookalike characters")
        if (host.matches(Regex("^(\\d{1,3}\\.){3}\\d{1,3}$"))) flags.add("Uses a raw IP address")
        if (host.split(".").size > 4) flags.add("Unusually many subdomains")
        if (Regex("login|verify|secure|account|update|banking", RegexOption.IGNORE_CASE).containsMatchIn(host))
            flags.add("Security-related words in domain; independently verify the organization")
        if (flags.isEmpty()) "No basic warning signs detected for $host. Domain reputation and ownership were NOT checked; this is not a safety guarantee."
        else "WARNING SIGNS for $host:\\n" + flags.joinToString("\\n") { "• $it" } + "\\nDo not proceed until independently verified."
    } catch (_: Exception) {
        "Invalid or unsupported URL. Enter a valid web address."
    }
}
