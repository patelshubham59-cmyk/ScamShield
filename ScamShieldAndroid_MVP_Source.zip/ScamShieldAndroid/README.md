# ScamShield Android MVP — Build 1

A native Android starter app built with Kotlin and Jetpack Compose.

## Included
- Message/email text checker using transparent local heuristic rules
- Basic URL pattern inspection
- Risk explanations and safety advice
- US/UK-oriented product shell

## Important limitations
This is an MVP prototype, not a production security product. It does not connect to live threat intelligence, verify sender identity, query reputation databases, or use a remote AI model. A low-risk result never means a message or link is safe. Do not enter real passwords, OTPs, financial details, or private messages during testing.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Extract this ZIP.
3. Open the `ScamShieldAndroid` folder in Android Studio.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press Run to install the app.
7. For an APK: Build → Build Bundle(s) / APK(s) → Build APK(s).
8. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Next production steps
- Add instrumented and unit tests, accessibility review, and security review.
- Add a backend API for AI analysis; never embed a secret API key in the Android app.
- Integrate reputable URL/domain threat intelligence with clear provenance and freshness.
- Add privacy disclosures, consent, retention controls, abuse monitoring, and incident response.
- Add localization and country-specific reporting guidance.
- Complete Google Play policy, data safety, and billing requirements before launch.
